
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Calendar, Clock, Car, Bike, Truck, CheckCircle, XCircle, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import BottomNav from '@/components/BottomNav';

const MyBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    setUser(currentUser);

    const allBookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    const userBookings = allBookings.filter(b => b.userId === currentUser.id);
    setBookings(userBookings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
  }, []);

  const getVehicleIcon = (type) => {
    switch(type) {
      case 'car': return Car;
      case 'motorcycle': return Bike;
      case 'truck': return Truck;
      default: return Car;
    }
  };

  const handlePayment = (bookingId) => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "O pagamento será implementado em breve! Você pode solicitar isso no próximo prompt! 🚀",
    });
  };

  const handleCancelBooking = (bookingId) => {
    const allBookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    const updatedBookings = allBookings.map(b => 
      b.id === bookingId ? {...b, status: 'cancelled'} : b
    );
    localStorage.setItem('bookings', JSON.stringify(updatedBookings));
    
    const userBookings = updatedBookings.filter(b => b.userId === user.id);
    setBookings(userBookings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));

    toast({
      title: "Agendamento cancelado",
      description: "Seu agendamento foi cancelado com sucesso",
    });
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'pending': return 'from-yellow-500/20 to-orange-500/20 border-yellow-500/30';
      case 'completed': return 'from-green-500/20 to-emerald-500/20 border-green-500/30';
      case 'cancelled': return 'from-red-500/20 to-pink-500/20 border-red-500/30';
      default: return 'from-gray-500/20 to-gray-600/20 border-gray-500/30';
    }
  };

  const getStatusText = (status) => {
    switch(status) {
      case 'pending': return 'Pendente';
      case 'completed': return 'Concluído';
      case 'cancelled': return 'Cancelado';
      default: return status;
    }
  };

  return (
    <>
      <Helmet>
        <title>Meus Agendamentos - LavaJato Pro</title>
        <meta name="description" content="Visualize seus agendamentos de lavagem" />
      </Helmet>
      <div className="min-h-screen pb-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDE2YzAtMi4yMSAxLjc5LTQgNC00czQgMS43OSA0IDQtMS43OSA0LTQgNC00LTEuNzktNC00em0wIDI0YzAtMi4yMSAxLjc5LTQgNC00czQgMS43OSA0IDQtMS43OSA0LTQgNC00LTEuNzktNC00ek0xMiAxNmMwLTIuMjEgMS43OS00IDQtNHM0IDEuNzkgNCA0LTEuNzkgNC00IDQtNC0xLjc5LTQtNHptMCAyNGMwLTIuMjEgMS43OS00IDQtNHM0IDEuNzkgNCA0LTEuNzkgNC00IDQtNC0xLjc5LTQtNHoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-20"></div>

        <div className="relative z-10 p-6">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Meus Agendamentos
            </h1>
            <p className="text-gray-400 mt-1">{bookings.length} agendamento(s)</p>
          </motion.div>

          <div className="space-y-4">
            {bookings.length === 0 ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="glass-effect rounded-3xl p-8 text-center"
              >
                <Calendar className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                <p className="text-gray-400">Você ainda não tem agendamentos</p>
              </motion.div>
            ) : (
              bookings.map((booking, index) => {
                const VehicleIcon = getVehicleIcon(booking.vehicleType);
                return (
                  <motion.div
                    key={booking.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`glass-effect rounded-3xl p-6 bg-gradient-to-br ${getStatusColor(booking.status)} border`}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                          <VehicleIcon className="w-6 h-6" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{booking.vehicleModel}</h3>
                          <p className="text-sm text-gray-400 capitalize">
                            {booking.washType === 'simple' ? 'Lavagem Simples' : 'Lavagem Completa'}
                          </p>
                        </div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        booking.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                        booking.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                        'bg-red-500/20 text-red-400'
                      }`}>
                        {getStatusText(booking.status)}
                      </span>
                    </div>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center gap-2 text-sm text-gray-400">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(booking.date).toLocaleDateString('pt-BR')}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400">
                        <Clock className="w-4 h-4" />
                        <span>{booking.time}</span>
                      </div>
                    </div>

                    {booking.status === 'pending' && (
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handlePayment(booking.id)}
                          className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                        >
                          <CreditCard className="w-4 h-4 mr-2" />
                          Pagar
                        </Button>
                        <Button
                          onClick={() => handleCancelBooking(booking.id)}
                          variant="destructive"
                          className="flex-1"
                        >
                          <XCircle className="w-4 h-4 mr-2" />
                          Cancelar
                        </Button>
                      </div>
                    )}

                    {booking.status === 'completed' && (
                      <div className="flex items-center gap-2 text-green-400 text-sm">
                        <CheckCircle className="w-4 h-4" />
                        <span>Serviço concluído com sucesso!</span>
                      </div>
                    )}
                  </motion.div>
                );
              })
            )}
          </div>
        </div>

        <BottomNav />
      </div>
    </>
  );
};

export default MyBookings;
  