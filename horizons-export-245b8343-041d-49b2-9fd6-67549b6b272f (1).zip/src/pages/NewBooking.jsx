
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { ArrowLeft, Car, Bike, Truck, Sparkles, Droplets } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';

const NewBooking = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    vehicleType: '',
    vehicleModel: '',
    washType: '',
    date: '',
    time: ''
  });

  useEffect(() => {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    setUser(currentUser);
  }, []);

  const vehicleTypes = [
    { value: 'car', label: 'Carro', icon: Car },
    { value: 'motorcycle', label: 'Moto', icon: Bike },
    { value: 'truck', label: 'Camionete', icon: Truck }
  ];

  const washTypes = [
    { value: 'simple', label: 'Lavagem Simples', price: 'R$ 30,00', icon: Droplets },
    { value: 'complete', label: 'Lavagem Completa', price: 'R$ 60,00', icon: Sparkles }
  ];

  const handleSubmit = (e) => {
    e.preventDefault();

    const booking = {
      id: Date.now().toString(),
      userId: user.id,
      ...formData,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    bookings.push(booking);
    localStorage.setItem('bookings', JSON.stringify(bookings));

    toast({
      title: "Agendamento criado! 🎉",
      description: "Você receberá uma notificação quando o serviço for concluído",
    });

    navigate('/my-bookings');
  };

  return (
    <>
      <Helmet>
        <title>Novo Agendamento - LavaJato Pro</title>
        <meta name="description" content="Agende uma lavagem para seu veículo" />
      </Helmet>
      <div className="min-h-screen pb-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDE2YzAtMi4yMSAxLjc5LTQgNC00czQgMS43OSA0IDQtMS43OSA0LTQgNC00LTEuNzktNC00em0wIDI0YzAtMi4yMSAxLjc5LTQgNC00czQgMS43OSA0IDQtMS43OSA0LTQgNC00LTEuNzktNC00ek0xMiAxNmMwLTIuMjEgMS43OS00IDQtNHM0IDEuNzkgNCA0LTEuNzkgNC00IDQtNC0xLjc5LTQtNHptMCAyNGMwLTIuMjEgMS43OS00IDQtNHM0IDEuNzkgNCA0LTEuNzkgNC00IDQtNC0xLjc5LTQtNHoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-20"></div>

        <div className="relative z-10 p-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-6"
          >
            <Button
              onClick={() => navigate('/dashboard')}
              variant="ghost"
              className="text-gray-400 hover:text-white -ml-2"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Voltar
            </Button>
            <h1 className="text-3xl font-bold mt-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Novo Agendamento
            </h1>
          </motion.div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="space-y-3"
            >
              <Label className="text-gray-300">Tipo de Veículo</Label>
              <div className="grid grid-cols-3 gap-3">
                {vehicleTypes.map((type) => {
                  const Icon = type.icon;
                  return (
                    <button
                      key={type.value}
                      type="button"
                      onClick={() => setFormData({...formData, vehicleType: type.value})}
                      className={`glass-effect rounded-2xl p-4 flex flex-col items-center gap-2 transition-all duration-300 ${
                        formData.vehicleType === type.value
                          ? 'bg-gradient-to-br from-purple-500/30 to-blue-500/30 border-2 border-purple-500'
                          : 'hover:bg-white/10'
                      }`}
                    >
                      <Icon className="w-8 h-8" />
                      <span className="text-xs font-medium text-center">{type.label}</span>
                    </button>
                  );
                })}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="space-y-2"
            >
              <Label htmlFor="vehicleModel" className="text-gray-300">Modelo do Veículo</Label>
              <Input
                id="vehicleModel"
                type="text"
                placeholder="Ex: Honda Civic 2020"
                value={formData.vehicleModel}
                onChange={(e) => setFormData({...formData, vehicleModel: e.target.value})}
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-purple-500"
                required
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-3"
            >
              <Label className="text-gray-300">Tipo de Lavagem</Label>
              <div className="space-y-3">
                {washTypes.map((wash) => {
                  const Icon = wash.icon;
                  return (
                    <button
                      key={wash.value}
                      type="button"
                      onClick={() => setFormData({...formData, washType: wash.value})}
                      className={`w-full glass-effect rounded-2xl p-4 flex items-center gap-4 transition-all duration-300 ${
                        formData.washType === wash.value
                          ? 'bg-gradient-to-br from-purple-500/30 to-blue-500/30 border-2 border-purple-500'
                          : 'hover:bg-white/10'
                      }`}
                    >
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6" />
                      </div>
                      <div className="flex-1 text-left">
                        <p className="font-semibold">{wash.label}</p>
                        <p className="text-sm text-gray-400">{wash.price}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="grid grid-cols-2 gap-4"
            >
              <div className="space-y-2">
                <Label htmlFor="date" className="text-gray-300">Data</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                  className="bg-white/5 border-white/10 text-white focus:border-purple-500"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="time" className="text-gray-300">Horário</Label>
                <Input
                  id="time"
                  type="time"
                  value={formData.time}
                  onChange={(e) => setFormData({...formData, time: e.target.value})}
                  className="bg-white/5 border-white/10 text-white focus:border-purple-500"
                  required
                />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-6 rounded-2xl shadow-lg shadow-purple-500/30 transition-all duration-300"
              >
                Confirmar Agendamento
              </Button>
            </motion.div>
          </form>
        </div>
      </div>
    </>
  );
};

export default NewBooking;
  