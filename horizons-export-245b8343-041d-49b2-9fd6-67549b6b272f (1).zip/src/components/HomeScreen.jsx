
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, User, Bell, LogOut, Sparkles, Car } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/customSupabaseClient';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const HomeScreen = ({ user, onNavigate, onLogout }) => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    const fetchBookings = async () => {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching bookings:', error);
      } else {
        setBookings(data);
      }
    };

    if (user) {
      fetchBookings();
    }
  }, [user]);

  const menuItems = [
    { icon: Calendar, title: 'Agendar Lavagem', description: 'Escolha o tipo de lavagem', color: 'from-blue-500 to-cyan-500', action: () => onNavigate('booking') },
    { icon: User, title: 'Meu Perfil', description: 'Dados e veículos', color: 'from-purple-500 to-pink-500', action: () => onNavigate('profile') },
    { icon: Bell, title: 'Notificações', description: 'Acompanhe seus serviços', color: 'from-orange-500 to-red-500', action: () => onNavigate('notifications') },
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="max-w-md mx-auto p-6 space-y-6">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full flex items-center justify-center shadow-lg overflow-hidden">
                {user.profile_picture_url ? <img src={user.profile_picture_url} alt="Foto de Perfil" className="w-full h-full object-cover" /> : <User className="w-8 h-8 text-white" />}
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">
                  Olá, {user?.name?.split(' ')[0]}! 👋
                </h2>
                <p className="text-sm text-gray-300">Bem - Vindo !!</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={onLogout} className="text-gray-300 hover:text-red-500">
              <LogOut className="w-5 h-5" />
            </Button>
          </div>

          <div className="bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl p-4 text-white shadow-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Sparkles className="w-5 h-5" />
              <span className="font-semibold">Promoção Especial</span>
            </div>
            <p className="text-sm opacity-90">
              20% OFF na primeira lavagem completa!
            </p>
          </div>
        </motion.div>

        <div className="space-y-4">
          {menuItems.map((item, index) => (
            <motion.div key={item.title} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.1 }}>
              <button onClick={item.action} className="w-full bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 shadow-lg hover:shadow-xl hover:bg-gray-700/60 transition-all group">
                <div className="flex items-center space-x-4">
                  <div className={`w-14 h-14 bg-gradient-to-br ${item.color} rounded-xl flex items-center justify-center shadow-md group-hover:scale-110 transition-transform`}>
                    <item.icon className="w-7 h-7 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-sm text-gray-300">{item.description}</p>
                  </div>
                  <div className="text-gray-500 group-hover:text-cyan-400 transition-colors">
                    →
                  </div>
                </div>
              </button>
            </motion.div>
          ))}
        </div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 shadow-lg">
          <div className="flex items-center space-x-3 mb-4">
            <Car className="w-6 h-6 text-cyan-400" />
            <h3 className="text-lg font-bold text-white">Serviços Recentes</h3>
          </div>
          {bookings.length === 0 ? (
            <p className="text-gray-400 text-center py-8">
              Nenhum serviço agendado ainda.
              <br />
              <span className="text-cyan-400 font-semibold">
                Agende sua primeira lavagem!
              </span>
            </p>
          ) : (
            <div className="space-y-3">
              {bookings.slice(0, 2).map(booking => (
                <div key={booking.id} className="bg-gray-700/50 rounded-xl p-3 flex justify-between items-center">
                  <div>
                    <p className="font-bold text-white">{booking.service}</p>
                    <p className="text-sm text-gray-300">{format(new Date(booking.booking_date), 'PPP', { locale: ptBR })} às {booking.booking_time}</p>
                  </div>
                  <span className={`text-xs font-bold py-1 px-2 rounded-full ${booking.status === 'paid' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                    {booking.status === 'paid' ? 'Pago' : 'Pendente'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};
export default HomeScreen;
