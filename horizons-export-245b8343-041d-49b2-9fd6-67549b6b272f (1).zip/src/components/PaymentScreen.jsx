
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, CreditCard, Smartphone, CheckCircle, Calendar, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useNavigate } from 'react-router-dom';

const paymentMethods = [
  { id: 'credit', name: 'Cartão de Crédito', icon: CreditCard, color: 'from-purple-500 to-indigo-500' },
  { id: 'pix', name: 'PIX', icon: Smartphone, color: 'from-teal-400 to-blue-500' },
];

const PaymentScreen = ({ booking, user, onBack, onPaymentComplete }) => {
  const [paymentMethod, setPaymentMethod] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [processing, setProcessing] = useState(false);
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    if (paymentConfirmed) {
      const timer = setTimeout(() => {
        onPaymentComplete();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [paymentConfirmed, onPaymentComplete]);

  if (!booking) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-6 text-center">
        <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-8 shadow-xl">
          <h1 className="text-2xl font-bold text-white mb-4">Nenhum agendamento ativo</h1>
          <p className="text-gray-300 mb-6">Parece que não há um agendamento em andamento para pagar.</p>
          <Button onClick={() => navigate('/')} className="w-full h-12 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all">
            Voltar para o Início
          </Button>
        </motion.div>
      </div>
    );
  }

  if (paymentConfirmed) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center p-6">
        <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-8 shadow-xl text-center max-w-md">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 0.2 }} className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-16 h-16 text-white" />
          </motion.div>
          <h1 className="text-3xl font-bold text-white mb-3">Pagamento Confirmado!</h1>
          <p className="text-gray-300 text-lg mb-2">Sua lavagem foi agendada com sucesso.</p>
          <div className="text-cyan-400 font-semibold text-xl">{booking.date} às {booking.time}</div>
          <p className="text-gray-400 mt-6 text-sm">Você será redirecionado em breve...</p>
        </motion.div>
      </div>
    );
  }

  const handlePayment = async () => {
    if (!paymentMethod) {
      toast({ title: "Atenção", description: "Selecione um método de pagamento.", variant: "destructive" });
      return;
    }
    if (paymentMethod === 'credit' && cardNumber.replace(/\s/g, '').length < 16) {
      toast({ title: "Atenção", description: "Preencha um número de cartão válido.", variant: "destructive" });
      return;
    }

    setProcessing(true);

    const { error: bookingError } = await supabase
      .from('bookings')
      .update({ status: 'paid', payment_method: paymentMethod })
      .eq('id', booking.id);

    if (bookingError) {
      toast({ title: "Erro no pagamento", description: bookingError.message, variant: "destructive" });
      setProcessing(false);
      return;
    }

    const { error: notificationError } = await supabase
      .from('notifications')
      .insert({
        user_id: user.id,
        title: 'Lavagem Agendada! 🎉',
        message: `Sua lavagem para ${booking.date} às ${booking.time} foi confirmada.`,
      });

    if (notificationError) {
      console.error("Error creating notification:", notificationError);
    }

    toast({ title: "Agendamento Confirmado! ✅", description: `Sua lavagem está marcada para ${booking.date} às ${booking.time}.` });
    setProcessing(false);
    setPaymentConfirmed(true);
  };

  const formatCardNumber = (value) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    return parts.length ? parts.join(' ') : value;
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="max-w-md mx-auto p-6 space-y-6">
        <div className="flex items-center space-x-4 mb-6">
          <Button variant="ghost" size="icon" onClick={onBack} className="rounded-full text-white hover:bg-gray-700"><ArrowLeft className="w-6 h-6" /></Button>
          <h1 className="text-2xl font-bold text-white">Pagamento</h1>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
          <h2 className="text-lg font-bold text-white mb-4">Resumo do Pedido</h2>
          <div className="space-y-3 mb-6">
            <div className="flex justify-between"><span className="text-gray-300">Veículo:</span><span className="font-semibold text-white">{booking.vehicle}</span></div>
            <div className="flex justify-between"><span className="text-gray-300">Serviço:</span><span className="font-semibold text-white">{booking.service}</span></div>
            <div className="flex justify-between items-center"><span className="text-gray-300 flex items-center"><Calendar className="w-4 h-4 mr-2"/>Data:</span><span className="font-semibold text-white">{booking.date}</span></div>
            <div className="flex justify-between items-center"><span className="text-gray-300 flex items-center"><Clock className="w-4 h-4 mr-2"/>Horário:</span><span className="font-semibold text-white">{booking.time}</span></div>
            <div className="border-t border-gray-700 pt-3 mt-3 flex justify-between"><span className="text-lg font-bold text-white">Total:</span><span className="text-2xl font-bold text-green-400">{booking.price}</span></div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
          <Label className="text-lg font-bold text-white mb-4 block">Método de Pagamento</Label>
          <div className="space-y-3 mb-6">
            {paymentMethods.map((method) => (
              <button key={method.id} onClick={() => setPaymentMethod(method.id)} className={`w-full p-5 rounded-2xl transition-all ${paymentMethod === method.id ? 'bg-gradient-to-br ' + method.color + ' text-white shadow-lg scale-105' : 'bg-gray-700 hover:bg-gray-600'}`}>
                <div className="flex items-center space-x-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${paymentMethod === method.id ? 'bg-white/20' : 'bg-gradient-to-br ' + method.color}`}><method.icon className="w-6 h-6 text-white" /></div>
                  <span className="font-semibold text-lg text-white">{method.name}</span>
                </div>
              </button>
            ))}
          </div>

          {paymentMethod === 'credit' && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="space-y-4">
              <div className="space-y-2"><Label className="text-gray-300">Número do Cartão</Label><Input placeholder="0000 0000 0000 0000" value={formatCardNumber(cardNumber)} onChange={(e) => setCardNumber(e.target.value)} maxLength={19} className="bg-gray-700 border-gray-600 text-white" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2"><Label className="text-gray-300">Validade</Label><Input placeholder="MM/AA" className="bg-gray-700 border-gray-600 text-white" /></div>
                <div className="space-y-2"><Label className="text-gray-300">CVV</Label><Input placeholder="000" maxLength={3} className="bg-gray-700 border-gray-600 text-white" /></div>
              </div>
            </motion.div>
          )}

          {paymentMethod === 'pix' && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="bg-gray-700 rounded-2xl p-6 text-center">
              <div className="w-48 h-48 mx-auto bg-white rounded-2xl flex items-center justify-center mb-4 p-2"><img alt="QR Code para pagamento via PIX" src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=chavepixaleatoria" /></div>
              <p className="text-sm text-gray-300">Escaneie o QR Code acima para realizar o pagamento</p>
            </motion.div>
          )}
        </motion.div>

        <Button onClick={handlePayment} disabled={processing} className="w-full h-14 bg-green-500 hover:bg-green-600 text-white font-bold text-lg rounded-2xl shadow-lg hover:shadow-xl transition-all">
          {processing ? <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}><CheckCircle className="w-6 h-6" /></motion.div> : <><CheckCircle className="w-6 h-6 mr-2" />Confirmar Agendamento</>}
        </Button>
      </div>
    </div>
  );
};

export default PaymentScreen;
