
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Car, Bike, Truck, Sparkles, Droplets, Calendar as CalendarIcon, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { supabase } from '@/lib/customSupabaseClient';

const BookingScreen = ({ user, onBack, onBookingCreated }) => {
  const [step, setStep] = useState(1);
  const [selectedVehicle, setSelectedVehicle] = useState('');
  const [selectedService, setSelectedService] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedTime, setSelectedTime] = useState('');

  const vehicleTypes = [
    { id: 'car', name: 'Carro', icon: Car, color: 'from-blue-500 to-cyan-500' },
    { id: 'bike', name: 'Moto', icon: Bike, color: 'from-green-500 to-emerald-500' },
    { id: 'truck', name: 'Camionete', icon: Truck, color: 'from-orange-500 to-red-500' },
  ];

  const serviceTypes = [
    { id: 'simple', name: 'Lavagem Simples', description: 'Lavagem externa + aspiração', price: 'R$ 35,00', priceValue: 35 },
    { id: 'complete', name: 'Lavagem Completa', description: 'Externa + interna + cera + hidratação', price: 'R$ 80,00', priceValue: 80 },
  ];

  const availableTimes = ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00"];

  const handleNextStep = () => {
    if (selectedVehicle && selectedService) {
      setStep(2);
    } else {
      toast({ title: "Atenção", description: "Selecione o veículo e o tipo de serviço.", variant: "destructive" });
    }
  };

  const handleBooking = async () => {
    if (!selectedDate || !selectedTime) {
      toast({ title: "Atenção", description: "Selecione a data e o horário.", variant: "destructive" });
      return;
    }

    const vehicle = vehicleTypes.find(v => v.id === selectedVehicle);
    const service = serviceTypes.find(s => s.id === selectedService);

    const bookingData = {
      user_id: user.id,
      vehicle: vehicle.name,
      service: service.name,
      price_value: service.priceValue,
      booking_date: format(selectedDate, 'yyyy-MM-dd'),
      booking_time: selectedTime,
    };

    const { data, error } = await supabase
      .from('bookings')
      .insert(bookingData)
      .select()
      .single();

    if (error) {
      toast({ title: "Erro ao agendar", description: error.message, variant: "destructive" });
    } else {
      const fullBookingDetails = {
        ...data,
        price: service.price,
        date: format(selectedDate, 'PPP', { locale: ptBR }),
        time: selectedTime,
      };
      toast({ title: "Agendamento criado! 🎉", description: "Prossiga para o pagamento." });
      onBookingCreated(fullBookingDetails);
    }
  };

  const renderStep1 = () => (
    <motion.div initial={{ opacity: 0, x: 300 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -300 }} transition={{ duration: 0.3 }} className="space-y-6">
      <div className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
        <Label className="text-lg font-bold text-white mb-4 block">Tipo de Veículo</Label>
        <div className="grid grid-cols-3 gap-3">
          {vehicleTypes.map((vehicle) => (
            <button key={vehicle.id} onClick={() => setSelectedVehicle(vehicle.id)} className={`p-4 rounded-2xl transition-all ${selectedVehicle === vehicle.id ? 'bg-gradient-to-br ' + vehicle.color + ' text-white shadow-lg scale-105' : 'bg-gray-700 text-white/80 hover:bg-gray-600'}`}>
              <vehicle.icon className="w-8 h-8 mx-auto mb-2" />
              <p className="text-xs font-semibold">{vehicle.name}</p>
            </button>
          ))}
        </div>
      </div>
      <div className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
        <Label className="text-lg font-bold text-white mb-4 block">Tipo de Serviço</Label>
        <div className="space-y-3">
          {serviceTypes.map((service) => (
            <button key={service.id} onClick={() => setSelectedService(service.id)} className={`w-full p-5 rounded-2xl transition-all text-left ${selectedService === service.id ? 'bg-gradient-to-br ' + (service.id === 'simple' ? 'from-blue-400 to-blue-600' : 'from-purple-500 to-pink-500') + ' text-white shadow-lg scale-105' : 'bg-gray-700 hover:bg-gray-600'}`}>
              <div className="flex items-start space-x-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${selectedService === service.id ? 'bg-white/20' : 'bg-gradient-to-br ' + (service.id === 'simple' ? 'from-blue-400 to-blue-600' : 'from-purple-500 to-pink-500')}`}>
                  {service.id === 'simple' ? <Droplets className="w-6 h-6 text-white" /> : <Sparkles className="w-6 h-6 text-white" />}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg mb-1 text-white">{service.name}</h3>
                  <p className={`text-sm mb-2 ${selectedService === service.id ? 'text-white/90' : 'text-gray-300'}`}>{service.description}</p>
                  <p className="font-bold text-xl text-white">{service.price}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
      <Button onClick={handleNextStep} className="w-full h-14 bg-green-500 hover:bg-green-600 text-white font-bold text-lg rounded-2xl shadow-lg hover:shadow-xl transition-all">Próximo</Button>
    </motion.div>
  );

  const renderStep2 = () => (
    <motion.div initial={{ opacity: 0, x: 300 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -300 }} transition={{ duration: 0.3 }} className="space-y-6">
      <div className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
        <Label className="text-lg font-bold text-white mb-4 block flex items-center"><CalendarIcon className="w-5 h-5 mr-2" />Selecione a Data</Label>
        <Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} className="rounded-md" locale={ptBR} disabled={(date) => date < new Date(new Date().setDate(new Date().getDate() - 1))} />
      </div>
      <div className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
        <Label className="text-lg font-bold text-white mb-4 block flex items-center"><Clock className="w-5 h-5 mr-2" />Selecione o Horário</Label>
        <div className="grid grid-cols-3 gap-3">
          {availableTimes.map((time) => (
            <button key={time} onClick={() => setSelectedTime(time)} className={`p-4 rounded-2xl transition-all font-semibold ${selectedTime === time ? 'bg-gradient-to-br from-blue-500 to-cyan-500 text-white shadow-lg scale-105' : 'bg-gray-700 text-white/80 hover:bg-gray-600'}`}>
              {time}
            </button>
          ))}
        </div>
      </div>
      <Button onClick={handleBooking} className="w-full h-14 bg-green-500 hover:bg-green-600 text-white font-bold text-lg rounded-2xl shadow-lg hover:shadow-xl transition-all">Continuar para Pagamento</Button>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="max-w-md mx-auto p-6 space-y-6">
        <div className="flex items-center space-x-4 mb-6">
          <Button variant="ghost" size="icon" onClick={step === 1 ? onBack : () => setStep(1)} className="rounded-full text-white hover:bg-gray-700">
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-2xl font-bold text-white">Agendar Lavagem</h1>
        </div>
        <AnimatePresence mode="wait">
          {step === 1 ? renderStep1() : renderStep2()}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default BookingScreen;
