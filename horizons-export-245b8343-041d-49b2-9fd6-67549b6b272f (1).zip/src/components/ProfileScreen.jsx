
import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, User, Mail, CreditCard, Car, Plus, Trash2, Camera, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const ProfileScreen = ({ user, onBack, onUpdateUser }) => {
  const [editableUser, setEditableUser] = useState({ ...user });
  const [vehicles, setVehicles] = useState([]);
  const [newVehicle, setNewVehicle] = useState({ model: '', plate: '', type: 'car' });
  const [dialogOpen, setDialogOpen] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    const fetchVehicles = async () => {
      const { data, error } = await supabase
        .from('vehicles')
        .select('*')
        .eq('user_id', user.id);
      if (error) console.error('Error fetching vehicles:', error);
      else setVehicles(data);
    };
    fetchVehicles();
  }, [user.id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditableUser(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveChanges = async () => {
    const { data, error } = await supabase
      .from('profiles')
      .update({ name: editableUser.name, email: editableUser.email, cpf: editableUser.cpf })
      .eq('id', user.id)
      .select()
      .single();

    if (error) {
      toast({ title: "Erro ao atualizar", description: error.message, variant: "destructive" });
    } else {
      onUpdateUser(data);
      toast({ title: "Perfil atualizado! ✅", description: "Suas informações foram salvas." });
    }
  };

  const handlePictureChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      toast({ title: "Arquivo muito grande!", description: "Selecione uma imagem menor que 2MB.", variant: "destructive" });
      return;
    }

    const filePath = `${user.id}/${Date.now()}`;
    const { error: uploadError } = await supabase.storage.from('profile-pictures').upload(filePath, file);

    if (uploadError) {
      toast({ title: "Erro no upload", description: uploadError.message, variant: "destructive" });
      return;
    }

    const { data: { publicUrl } } = supabase.storage.from('profile-pictures').getPublicUrl(filePath);

    const { data, error: updateError } = await supabase
      .from('profiles')
      .update({ profile_picture_url: publicUrl })
      .eq('id', user.id)
      .select()
      .single();

    if (updateError) {
      toast({ title: "Erro ao salvar URL", description: updateError.message, variant: "destructive" });
    } else {
      onUpdateUser(data);
      toast({ title: "Foto de perfil atualizada! ✨" });
    }
  };

  const handleAddVehicle = async () => {
    if (!newVehicle.model || !newVehicle.plate) {
      toast({ title: "Atenção", description: "Preencha todos os campos.", variant: "destructive" });
      return;
    }

    const { data, error } = await supabase
      .from('vehicles')
      .insert({ ...newVehicle, user_id: user.id })
      .select()
      .single();

    if (error) {
      toast({ title: "Erro ao adicionar veículo", description: error.message, variant: "destructive" });
    } else {
      setVehicles(prev => [...prev, data]);
      toast({ title: "Veículo adicionado! 🚗" });
      setNewVehicle({ model: '', plate: '', type: 'car' });
      setDialogOpen(false);
    }
  };

  const handleRemoveVehicle = async (vehicleId) => {
    const { error } = await supabase.from('vehicles').delete().eq('id', vehicleId);
    if (error) {
      toast({ title: "Erro ao remover veículo", description: error.message, variant: "destructive" });
    } else {
      setVehicles(prev => prev.filter(v => v.id !== vehicleId));
      toast({ title: "Veículo removido" });
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="max-w-md mx-auto p-6 space-y-6">
        <div className="flex items-center space-x-4 mb-6">
          <Button variant="ghost" size="icon" onClick={onBack} className="rounded-full text-white hover:bg-gray-700">
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-2xl font-bold text-white">Meu Perfil</h1>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <button onClick={() => fileInputRef.current.click()} className="w-24 h-24 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full flex items-center justify-center shadow-lg overflow-hidden">
                {editableUser.profile_picture_url ? <img src={editableUser.profile_picture_url} alt="Foto de Perfil" className="w-full h-full object-cover" /> : <User className="w-12 h-12 text-white" />}
              </button>
              <input type="file" ref={fileInputRef} onChange={handlePictureChange} className="hidden" accept="image/*" />
              <div className="absolute bottom-0 right-0 bg-white rounded-full p-1 shadow-md cursor-pointer" onClick={() => fileInputRef.current.click()}>
                <Camera className="w-4 h-4 text-gray-700" />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-gray-300 font-medium flex items-center"><User className="w-4 h-4 mr-2" />Nome</Label>
              <Input name="name" value={editableUser.name || ''} onChange={handleInputChange} className="bg-gray-700 border-gray-600 text-white" />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300 font-medium flex items-center"><Mail className="w-4 h-4 mr-2" />Email</Label>
              <Input name="email" type="email" value={editableUser.email || ''} onChange={handleInputChange} className="bg-gray-700 border-gray-600 text-white" />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300 font-medium flex items-center"><CreditCard className="w-4 h-4 mr-2" />CPF</Label>
              <Input name="cpf" value={editableUser.cpf || ''} onChange={handleInputChange} className="bg-gray-700 border-gray-600 text-white" />
            </div>
          </div>
          <Button onClick={handleSaveChanges} className="w-full mt-6 bg-green-500 hover:bg-green-600 text-white font-bold text-lg rounded-2xl shadow-lg hover:shadow-xl transition-all">
            <Save className="w-5 h-5 mr-2" />Salvar Alterações
          </Button>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <Label className="text-lg font-bold text-white flex items-center"><Car className="w-5 h-5 mr-2" />Meus Veículos</Label>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="bg-blue-500 hover:bg-blue-600 text-white rounded-xl"><Plus className="w-4 h-4 mr-1" />Adicionar</Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-800 border-gray-700 rounded-3xl text-white">
                <DialogHeader><DialogTitle className="text-white">Adicionar Veículo</DialogTitle></DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label className="text-gray-300">Modelo</Label>
                    <Input placeholder="Ex: Honda Civic 2020" value={newVehicle.model} onChange={(e) => setNewVehicle({ ...newVehicle, model: e.target.value })} className="bg-gray-700 border-gray-600 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-300">Placa</Label>
                    <Input placeholder="ABC-1234" value={newVehicle.plate} onChange={(e) => setNewVehicle({ ...newVehicle, plate: e.target.value.toUpperCase() })} className="bg-gray-700 border-gray-600 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-300">Tipo</Label>
                    <select value={newVehicle.type} onChange={(e) => setNewVehicle({ ...newVehicle, type: e.target.value })} className="w-full h-10 px-3 rounded-md border border-gray-600 bg-gray-700 text-white">
                      <option value="car">Carro</option>
                      <option value="bike">Moto</option>
                      <option value="truck">Camionete</option>
                    </select>
                  </div>
                  <Button onClick={handleAddVehicle} className="w-full bg-blue-500 hover:bg-blue-600 text-white">Adicionar Veículo</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          {vehicles.length === 0 ? <p className="text-gray-400 text-center py-8">Nenhum veículo cadastrado.</p> : (
            <div className="space-y-3">
              {vehicles.map((vehicle) => (
                <div key={vehicle.id} className="bg-gray-700/50 rounded-2xl p-4 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center"><Car className="w-6 h-6 text-white" /></div>
                    <div>
                      <p className="font-semibold text-white">{vehicle.model}</p>
                      <p className="text-sm text-gray-400">{vehicle.plate}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => handleRemoveVehicle(vehicle.id)} className="text-red-500 hover:text-red-600"><Trash2 className="w-5 h-5" /></Button>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default ProfileScreen;
