
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Routes, Route, useNavigate, Navigate, Outlet } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import LoginScreen from '@/components/LoginScreen';
import RegisterScreen from '@/components/RegisterScreen';
import HomeScreen from '@/components/HomeScreen';
import BookingScreen from '@/components/BookingScreen';
import ProfileScreen from '@/components/ProfileScreen';
import PaymentScreen from '@/components/PaymentScreen';
import NotificationsScreen from '@/components/NotificationsScreen';

const ProtectedRoute = ({ user }) => {
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  return <Outlet />;
};

function App() {
  const { user, session, loading: authLoading } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loadingProfile, setLoadingProfile] = useState(true);
  const [currentBooking, setCurrentBooking] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      const fetchProfile = async () => {
        setLoadingProfile(true);
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error) {
          console.error('Error fetching profile:', error);
        } else {
          setProfile(data);
        }
        setLoadingProfile(false);
      };
      fetchProfile();
    } else {
      setProfile(null);
      setLoadingProfile(false);
    }
  }, [user]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setCurrentBooking(null);
    navigate('/login');
  };

  const handleBookingCreated = (booking) => {
    setCurrentBooking(booking);
    navigate('/payment');
  };

  const handlePaymentComplete = () => {
    setCurrentBooking(null);
    navigate('/');
  };

  const handleUpdateProfile = (updatedProfile) => {
    setProfile(updatedProfile);
  };

  const isLoading = authLoading || loadingProfile;

  if (isLoading) {
    return <div className="min-h-screen w-full flex items-center justify-center bg-gray-900"></div>;
  }

  return (
    <>
      <Helmet>
        <title>LavaJato Express - Lavagem Rápida e Prática</title>
        <meta name="description" content="Agende sua lavagem de veículo de forma rápida e prática. Sistema completo de agendamento, pagamento e notificações." />
      </Helmet>
      <div className="min-h-screen pb-safe bg-gray-900">
        <Routes>
          <Route path="/login" element={!user ? <LoginScreen /> : <Navigate to="/" />} />
          <Route path="/register" element={!user ? <RegisterScreen /> : <Navigate to="/" />} />
          
          <Route element={<ProtectedRoute user={user} />}>
            {profile && (
              <>
                <Route path="/" element={<HomeScreen user={profile} onNavigate={(path) => navigate(`/${path}`)} onLogout={handleLogout} />} />
                <Route path="/booking" element={<BookingScreen user={profile} onBack={() => navigate('/')} onBookingCreated={handleBookingCreated} />} />
                <Route path="/profile" element={<ProfileScreen user={profile} onBack={() => navigate('/')} onUpdateUser={handleUpdateProfile} />} />
                <Route path="/payment" element={<PaymentScreen booking={currentBooking} user={profile} onBack={() => navigate('/booking')} onPaymentComplete={handlePaymentComplete} />} />
                <Route path="/notifications" element={<NotificationsScreen user={profile} onBack={() => navigate('/')} />} />
              </>
            )}
          </Route>
          
          <Route path="*" element={<Navigate to={user ? "/" : "/login"} />} />
        </Routes>
        <Toaster />
      </div>
    </>
  );
}

export default App;
